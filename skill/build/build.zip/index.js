// blip
